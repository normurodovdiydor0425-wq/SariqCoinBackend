# Backend
Node.js 20+ API va Telegram bot. `server.mjs`, `src/`, `test/`, `data/` shu yerda.

`node server.mjs` yoki `npm start`. Asosiy demo: `npm test`.
Backend boshqa katalogdan yurgizilsa ham `.env` o‘sha `backend/` ichidan o‘qiladi.

Frontend boshqa joyda bo‘lsa `FRONTEND_DIR` orqali frontendning **public** katalogiga yo‘l ko‘rsating.
Avtomatik qiymat: `../frontend/public`.

Frontend bilan birga bitta origin ishlatish tavsiya etiladi; bunda cross-origin cookie, CORS yoki autentifikatsiyani qayta yozish shart emas.

`DATA_FILE` va `VIDEO_MEDIA_DIR` maxfiy ma’lumotlar uchun. `.env`ni, real `.json` bazani ZIP va Gitga qo‘shmang.
